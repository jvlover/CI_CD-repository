drop database if exists ssafit_inside;
drop table if exists user;
drop table if exists zzim_video;
drop table if exists board;
drop table if exists board_comment;

create database ssafit_inside;
use ssafit_inside;

create table user (
	`id` varchar(40) primary key,
    `password` varchar(40) not null,
    `email` varchar(40) not null,
    `name` varchar(40) character set utf8mb4 not null,
    `height` int not null,
    `weight` int not null,
    `exp` int default 0,
    `statusMessage` varchar(500) character set utf8mb4 default null,
    `profileImg` varchar(100) default null,
    `backgroundImg` varchar(100) default null
)ENGINE=InnoDB;


insert into user (`id`, `password`, `email`, `name`, `height`, `weight`, `backgroundImg`)
values('ssafy', '1234', 'ssafy@ssafy.com', '김싸피', 180, 80, '/background/background2.jpg');



create table zzim_video (
	`youtubeId` varchar(400),
    `title` varchar(400) not null,
    `channelName` varchar(400) not null,
    `userId` varchar(40) not null,
    PRIMARY KEY(`youtubeId`, `userId`),
    CONSTRAINT `fk_zzim_userId`
    FOREIGN KEY (`userId`)
    REFERENCES ssafit_inside.user (`id`)
)ENGINE=InnoDB;

create table board (
	`boardNum` int auto_increment primary key,
    `title` varchar(100) not null,
    `content` varchar(500) not null,
    `viewCnt` int default 0,
    `likeCnt` int default 0,
    `hateCnt` int default 0,
	`userId` varchar(40) not null,
    `regDate` datetime not null,
    CONSTRAINT `fk_board_userId`
    FOREIGN KEY (`userId`)
    REFERENCES ssafit_inside.user (`id`)
)ENGINE=InnoDB;

create table board_comment (
	`commentNum` int auto_increment primary key,
	`content` varchar(500) not null,
    `boardNum` int not null,
    `userId` varchar(40) not null,
    `regDate` datetime not null,
    CONSTRAINT `fk_comment_userId`
    FOREIGN KEY (`userId`)
    REFERENCES ssafit_inside.user (`id`),
    CONSTRAINT `fk_comment_boardNum`
    FOREIGN KEY (`boardNum`)
    REFERENCES ssafit_inside.board (`boardNum`)
    ON DELETE CASCADE
)ENGINE=InnoDB;

insert into board (boardNum, title, content, userId, regDate)
VALUES (0, "rotlqkf", "ㅁㄴㄻㄴ", "ssafy", now());

select * from board;

insert into board_comment(commentNum, content, boardNum, userId, regDate)
VALUES (0, "되냐", 1, "ssafy", now());

select * from user;

select * from zzim_video;



